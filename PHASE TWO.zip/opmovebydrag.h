//#pragma once
//#include"operations/operation.h"
//#include "controller.h"
//
//class MoveByDrag : public operation
//{
//private:
//	int dx;
//	int dy;
//
//public:
//	MoveByDrag(controller* pCont);
//	virtual void ReadActionParameters();
//	virtual void Execute();
//};
